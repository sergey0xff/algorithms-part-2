public class MSDIndexSort {
    private char[] chars;
    private int[] indexes;

    public MSDIndexSort(String s, int[] indexes) {
        this.chars = s.toCharArray();
        this.indexes = indexes;
        sort(0, indexes.length - 1, 0);
    }

    private void sort(int lo, int hi, int offset) {
        if (lo >= hi || offset >= chars.length) return;

        int lt = lo, gt = hi;
        char a = charAt(lo, offset);
        int i = lo + 1;

        while (i <= gt) {
            char b = charAt(i, offset);

            if (b < a) {
                exch(lt++, i++);
            } else if (b > a) {
                exch(i, gt--);
            } else {
                i++;
            }
        }

        sort(lo, lt - 1, offset);

        if (lt != gt) {
            sort(lt, gt, offset + 1);
        }

        sort(gt + 1, hi, offset);
    }

    private void exch(int i, int j) {
        int tmp = indexes[i];
        indexes[i] = indexes[j];
        indexes[j] = tmp;
    }

    private char charAt(int i, int offset) {
        return chars[(indexes[i] + offset) % chars.length];
    }
}
