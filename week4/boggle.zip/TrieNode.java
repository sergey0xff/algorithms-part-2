public class TrieNode {
    TrieNode[] next = new TrieNode[26];
    boolean isString;
}
